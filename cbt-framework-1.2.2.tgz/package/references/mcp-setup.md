# MCP Server Setup for Trading

> How to set up MCP (Model Context Protocol) servers for enhanced trading development

## What is MCP?

MCP (Model Context Protocol) allows Claude Code to connect to external tools and data sources.
For trading development, this means:
- Access to library documentation (ccxt, polars, numba, pandas, etc.)
- Live market data feeds
- Economic calendar data

## Recommended MCP Servers

### 1. Context7 - Library Documentation

Context7 provides up-to-date documentation for any library directly in Claude Code.

**Setup:**
Add to `~/.claude/settings.json`:
```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp@latest"]
    }
  }
}
```

**Usage in Claude Code:**
- Automatically provides docs for: ccxt, polars, numba, pandas, numpy, matplotlib, seaborn
- Ask Claude to look up specific API methods
- Get accurate, version-specific documentation

### 2. Trading Data MCP Servers

For live market data access within Claude Code:

**CoinGecko / CryptoCompare:**
Check the MCP server registry for available crypto data servers.
These provide real-time price data, market cap, and volume.

**Alpha Vantage:**
For stock/forex data, look for Alpha Vantage MCP servers.

### 3. Economic Calendar

For fundamental data and event-driven strategies:
- Look for economic calendar MCP servers in the registry
- Provides: FOMC dates, CPI releases, employment data, etc.

## Setting Up MCP Servers

### Manual Setup

1. Open `~/.claude/settings.json`
2. Add the `mcpServers` section:

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp@latest"]
    }
  }
}
```

3. Restart Claude Code

### Via CBT Framework Installer

Run:
```bash
npx cbt-framework
```

The installer will ask: "Would you like to set up MCP servers for trading docs & live data?"

If yes, it automatically configures:
- Context7 (library documentation)
- Any available trading-specific MCP servers

### Verifying MCP Setup

In Claude Code, test by asking:
- "Look up ccxt create_order documentation"
- "What are the Polars LazyFrame methods?"
- "Show me Numba @njit documentation"

If Context7 is working, you'll get accurate, current documentation.

## Available Libraries via Context7

Useful for CBT Framework development:

| Library | Use Case |
|---------|----------|
| ccxt | Exchange API interaction (live trading) |
| polars | Fast data loading and manipulation |
| numba | JIT compilation for backtest loops |
| pandas | Standard data manipulation |
| numpy | Numerical operations |
| matplotlib | Plotting and visualization |
| seaborn | Statistical visualizations |
| mplfinance | Candlestick charts |
| scikit-learn | ML models for complex strategies |
| scipy | Statistical tests for EDA |

## Troubleshooting

| Issue | Solution |
|-------|----------|
| MCP server not connecting | Check `~/.claude/settings.json` syntax |
| "Command not found" | Ensure Node.js/npx is installed |
| Slow responses | MCP servers add latency; use sparingly |
| Incorrect docs | Specify library version in your query |

## Security Notes

- MCP servers run locally on your machine
- They do NOT have access to your API keys or .env files
- Context7 only fetches public documentation
- Review any MCP server code before installing
